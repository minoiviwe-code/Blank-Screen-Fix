import React from 'react';

const Auth: React.FC = () => {
  return (
    <div>
      {/* Your auth page here */}
    </div>
  );
};

export default Auth;
