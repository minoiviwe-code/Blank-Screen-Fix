import React from 'react';

const PoolAgreement: React.FC = () => {
  return (
    <div>
      {/* Your pool agreement page here */}
    </div>
  );
};

export default PoolAgreement;
