import React from 'react';

const Prospectus: React.FC = () => {
  return (
    <div>
      {/* Your prospectus page here */}
    </div>
  );
};

export default Prospectus;
