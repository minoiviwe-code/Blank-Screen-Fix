import React from 'react';

const CreatePool: React.FC = () => {
  return (
    <div>
      {/* Your create pool page here */}
    </div>
  );
};

export default CreatePool;
